# فونت وزیر
فایل‌های TTF باید با نام‌های زیر در این پوشه قرار بگیرند:
- Vazir-Light.ttf
- Vazir-Medium.ttf
- Vazir-Bold.ttf

pubspec.yaml از همین مسیرها استفاده می‌کند.
