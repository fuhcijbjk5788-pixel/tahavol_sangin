# آیکون‌ها

truck.png, box.png, chat.png, profile.png, home.png
