# تصاویر پروژه

logo.png و admin_logo.png و splash_bg.png و empty_state.png در این پوشه قرار می‌گیرند.
