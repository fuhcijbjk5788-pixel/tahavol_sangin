import 'package:flutter/material.dart';

class AppTheme {
  static const Color darkGreen = Color(0xFF155B3A);
  static const Color lightGreen = Color(0xFF7BC47F);
  static const Color surface = Color(0xFFF8FBF9);

  static ThemeData _base(Brightness brightness) {
    final isDark = brightness == Brightness.dark;
    return ThemeData(
      brightness: brightness,
      primaryColor: isDark ? lightGreen : darkGreen,
      scaffoldBackgroundColor: isDark ? const Color(0xFF101712) : surface,
      fontFamily: 'Vazir',
      colorScheme: ColorScheme.fromSeed(
        seedColor: darkGreen,
        brightness: brightness,
      ),
      cardTheme: CardThemeData(
        elevation: 3,
        shadowColor: Colors.black26,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: isDark ? lightGreen : darkGreen,
          foregroundColor: Colors.white,
          minimumSize: const Size(double.infinity, 48),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: isDark ? const Color(0xFF18221B) : Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(
            color: isDark ? lightGreen : darkGreen,
            width: 1.5,
          ),
        ),
      ),
    );
  }

  static ThemeData get lightTheme => _base(Brightness.light);
  static ThemeData get darkTheme => _base(Brightness.dark);
}
