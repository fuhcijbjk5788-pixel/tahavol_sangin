class AppConfig {
  static const String appName = 'تحول سنگین';
  static const String appNameEn = 'Tahavol Sangin';
  static const String appVersion = '1.0.0';
  static const String slogan = 'حمل‌ونقل هوشمند، مسیری مطمئن';

  static const String adminAppName = 'مرکز فرماندهی';
  static const String adminAppNameEn = 'Command Center';

  static const String baseUrl = 'https://api.tahavolsangin.ir';
  static const String mapsApiKey = '';

  static const String tokenKey = 'auth_token';
  static const String userIdKey = 'user_id';
  static const String userRoleKey = 'user_role';

  static const int pricePerKm = 2000;
  static const int pricePerTon = 500;
}
