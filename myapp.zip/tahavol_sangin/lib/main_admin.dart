import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'config/app_theme.dart';
import 'screens/admin/admin_login_screen.dart';
import 'screens/admin/admin_panel_screen.dart';
import 'screens/admin/admin_splash_screen.dart';
import 'screens/admin/manage_admins_screen.dart';
import 'screens/admin/manage_loads_screen.dart';
import 'screens/admin/manage_users_screen.dart';
import 'screens/admin/notifications_screen.dart';
import 'screens/admin/reports_screen.dart';
import 'screens/admin/review_documents_screen.dart';
import 'screens/admin/tickets_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const AdminApp());
}

class AdminApp extends StatelessWidget {
  const AdminApp({super.key});
  @override
  Widget build(BuildContext context) => GetMaterialApp(
    title: 'مرکز فرماندهی',
    debugShowCheckedModeBanner: false,
    theme: AppTheme.lightTheme,
    darkTheme: AppTheme.darkTheme,
    themeMode: ThemeMode.system,
    locale: const Locale('fa', 'IR'),
    fallbackLocale: const Locale('fa', 'IR'),
    initialRoute: '/admin_splash',
    getPages: [
      GetPage(name: '/admin_splash', page: () => const AdminSplashScreen()),
      GetPage(name: '/admin_login', page: () => const AdminLoginScreen()),
      GetPage(name: '/admin_panel', page: () => const AdminPanelScreen()),
      GetPage(name: '/admin/users', page: () => const ManageUsersScreen()),
      GetPage(name: '/admin/documents', page: () => const ReviewDocumentsScreen()),
      GetPage(name: '/admin/loads', page: () => const ManageLoadsScreen()),
      GetPage(name: '/admin/reports', page: () => const ReportsScreen()),
      GetPage(name: '/admin/admins', page: () => const ManageAdminsScreen()),
      GetPage(name: '/admin/notifications', page: () => const AdminNotificationsScreen()),
      GetPage(name: '/admin/tickets', page: () => const TicketsScreen()),
    ],
  );
}
