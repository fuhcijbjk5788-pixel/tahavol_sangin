import '../models/load.dart';

class LoadService {
  List<LoadModel> mockLoads() => const [
        LoadModel(
          id: '1',
          title: 'بار عمومی',
          origin: 'کرج',
          destination: 'اهواز',
          weight: 12,
          fare: 24000000,
          type: LoadType.specified,
          routeType: RouteType.interProvincial,
        ),
        LoadModel(
          id: '2',
          title: 'بار فوری',
          origin: 'تهران',
          destination: 'قم',
          weight: 8,
          fare: 8500000,
          type: LoadType.instant,
          routeType: RouteType.interProvincial,
        ),
      ];
}
