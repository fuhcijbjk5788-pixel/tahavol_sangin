import 'package:flutter/material.dart';
import 'package:get/get.dart';

class DriverHomeScreen extends StatelessWidget {
  const DriverHomeScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('خانه راننده')),
    body: GridView.count(crossAxisCount: 2, padding: const EdgeInsets.all(16), children: [
      _item(context, Icons.local_shipping, 'بارهای موجود', '/driver/loads'),
      _item(context, Icons.chat, 'گفتگوها', '/chats'),
      _item(context, Icons.person, 'پروفایل', '/profile'),
      _item(context, Icons.support_agent, 'پشتیبانی', '/support'),
    ]),
  );
}
Widget _item(BuildContext context, IconData icon, String text, String route) =>
  Card(child: InkWell(onTap: () => Get.toNamed(route), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    Icon(icon, size: 42), const SizedBox(height: 8), Text(text)
  ])));
