import 'package:flutter/material.dart';
import '../../services/load_service.dart';

class DriverLoadsScreen extends StatelessWidget {
  const DriverLoadsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final loads = LoadService().mockLoads();
    return Scaffold(
      appBar: AppBar(title: const Text('لیست بارها')),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: loads.length,
        itemBuilder: (_, i) {
          final l = loads[i];
          return Card(child: ListTile(
            leading: const Icon(Icons.local_shipping),
            title: Text(l.title),
            subtitle: Text('${l.origin} ← ${l.destination}\nوزن: ${l.weight} تن'),
            trailing: Text('${l.fare.toStringAsFixed(0)} تومان'),
          ));
        },
      ),
    );
  }
}
