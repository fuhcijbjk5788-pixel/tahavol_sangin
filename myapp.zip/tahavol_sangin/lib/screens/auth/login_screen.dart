import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/custom_textfield.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override State<LoginScreen> createState() => _LoginScreenState();
}
class _LoginScreenState extends State<LoginScreen> {
  final phone = TextEditingController();
  final password = TextEditingController();
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('ورود')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      const Text('تحول سنگین', textAlign: TextAlign.center, style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
      const SizedBox(height: 24),
      CustomTextField(label: 'شماره تلفن', controller: phone, keyboardType: TextInputType.phone),
      const SizedBox(height: 12),
      CustomTextField(label: 'رمز عبور', controller: password, obscureText: true),
      const SizedBox(height: 20),
      CustomButton(text: 'ورود راننده', onPressed: () => Get.offNamed('/driver/home')),
      const SizedBox(height: 10),
      CustomButton(text: 'ثبت‌نام راننده', onPressed: () => Get.toNamed('/register/driver')),
      const SizedBox(height: 10),
      OutlinedButton(onPressed: () => Get.toNamed('/register/owner'), child: const Text('ثبت‌نام صاحب بار')),
    ]),
  );
}
