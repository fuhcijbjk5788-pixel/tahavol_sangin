import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/custom_textfield.dart';

class DriverRegisterScreen extends StatelessWidget {
  const DriverRegisterScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('ثبت‌نام راننده')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      const Text('اطلاعات هویتی و مدارک راننده'),
      const SizedBox(height: 16),
      const CustomTextField(label: 'نام و نام خانوادگی'),
      const SizedBox(height: 12),
      const CustomTextField(label: 'شماره تلفن', keyboardType: TextInputType.phone),
      const SizedBox(height: 12),
      const CustomTextField(label: 'شماره پلاک'),
      const SizedBox(height: 20),
      CustomButton(text: 'ثبت اطلاعات', onPressed: () => Get.offNamed('/driver/home')),
    ]),
  );
}
