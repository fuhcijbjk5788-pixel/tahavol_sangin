import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/custom_textfield.dart';

class OwnerRegisterScreen extends StatelessWidget {
  const OwnerRegisterScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('ثبت‌نام صاحب بار')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      const CustomTextField(label: 'نام و نام خانوادگی / نام شرکت'),
      const SizedBox(height: 12),
      const CustomTextField(label: 'شماره تلفن', keyboardType: TextInputType.phone),
      const SizedBox(height: 12),
      const CustomTextField(label: 'توضیحات'),
      const SizedBox(height: 20),
      CustomButton(text: 'ثبت اطلاعات', onPressed: () => Get.offNamed('/owner/home')),
    ]),
  );
}
