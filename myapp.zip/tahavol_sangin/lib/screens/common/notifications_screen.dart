import 'package:flutter/material.dart';
class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('اعلان‌ها')),
    body: const Center(child: Padding(padding: EdgeInsets.all(20), child: Text('در حال حاضر اعلان جدیدی وجود ندارد.', textAlign: TextAlign.center))),
  );
}
