import 'package:flutter/material.dart';
class TermsScreen extends StatelessWidget {
  const TermsScreen({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('قوانین و مقررات')),
    body: const Center(child: Padding(padding: EdgeInsets.all(20), child: Text('این برنامه به‌عنوان بستر معرفی بار و راننده فعالیت می‌کند. مسئولیت توافق و اجرای حمل بر عهده طرفین است.', textAlign: TextAlign.center))),
  );
}
