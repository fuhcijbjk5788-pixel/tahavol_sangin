import 'package:flutter/material.dart';
class SupportScreen extends StatelessWidget {
  const SupportScreen({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('پشتیبانی')),
    body: const Center(child: Padding(padding: EdgeInsets.all(20), child: Text('برای پشتیبانی، تیکت خود را ثبت کنید.', textAlign: TextAlign.center))),
  );
}
