import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('پروفایل')),
    body: ListView(children: const [
      ListTile(leading: CircleAvatar(child: Icon(Icons.person)), title: Text('کاربر نمونه'), subtitle: Text('اطلاعات حساب')),
      ListTile(leading: Icon(Icons.security), title: Text('امنیت و حریم خصوصی')),
      ListTile(leading: Icon(Icons.settings), title: Text('تنظیمات')),
    ]),
  );
}
