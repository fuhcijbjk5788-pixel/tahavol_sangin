import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../services/load_service.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/custom_textfield.dart';

class OwnerLoadsScreen extends StatelessWidget {
  const OwnerLoadsScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('مدیریت بارها')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      CustomButton(text: 'ثبت بار جدید', onPressed: () => Get.dialog(AlertDialog(
        title: const Text('ثبت بار'),
        content: const Column(mainAxisSize: MainAxisSize.min, children: [
          CustomTextField(label: 'مبدا'), SizedBox(height: 10), CustomTextField(label: 'مقصد'),
        ]),
        actions: [TextButton(onPressed: Get.back, child: const Text('بستن'))],
      ))),
      const SizedBox(height: 12),
      ...LoadService().mockLoads().map((l) => Card(child: ListTile(
        title: Text(l.title), subtitle: Text('${l.origin} ← ${l.destination}'),
      ))),
    ]),
  );
}
