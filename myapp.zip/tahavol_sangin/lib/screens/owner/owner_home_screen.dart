import 'package:flutter/material.dart';
import 'package:get/get.dart';

class OwnerHomeScreen extends StatelessWidget {
  const OwnerHomeScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('خانه صاحب بار')),
    floatingActionButton: FloatingActionButton.extended(
      onPressed: () => Get.toNamed('/owner/loads'),
      label: const Text('ثبت بار'), icon: const Icon(Icons.add),
    ),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: ListTile(title: const Text('بارهای من'), trailing: const Icon(Icons.chevron_left),
        onTap: () => Get.toNamed('/owner/loads'))),
      Card(child: ListTile(title: const Text('گفتگوها'), trailing: const Icon(Icons.chevron_left),
        onTap: () => Get.toNamed('/chats'))),
    ]),
  );
}
