import 'package:flutter/material.dart';
class ManageUsersScreen extends StatelessWidget {
  const ManageUsersScreen({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('مدیریت کاربران')),
    body: Center(child: Padding(padding: const EdgeInsets.all(20), child: Text('لیست کاربران و وضعیت حساب‌ها', textAlign: TextAlign.center))),
  );
}
