import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AdminPanelScreen extends StatelessWidget {
  const AdminPanelScreen({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('مرکز فرماندهی')),
    body: ListView(padding: const EdgeInsets.all(12), children: [
      _row('مدیریت کاربران', '/admin/users', Icons.people),
      _row('بررسی مدارک', '/admin/documents', Icons.fact_check),
      _row('مدیریت بارها', '/admin/loads', Icons.inventory_2),
      _row('گزارشات', '/admin/reports', Icons.bar_chart),
      _row('مدیریت مدیران', '/admin/admins', Icons.admin_panel_settings),
      _row('اعلان‌ها', '/admin/notifications', Icons.notifications),
      _row('تیکت‌های پشتیبانی', '/admin/tickets', Icons.support_agent),
    ]),
  );
}
Widget _row(String t, String r, IconData i) => Card(child: ListTile(leading: Icon(i), title: Text(t), trailing: const Icon(Icons.chevron_left), onTap: () => Get.toNamed(r)));
