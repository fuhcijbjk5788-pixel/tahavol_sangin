import 'package:flutter/material.dart';
class ReviewDocumentsScreen extends StatelessWidget {
  const ReviewDocumentsScreen({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('بررسی مدارک')),
    body: Center(child: Padding(padding: const EdgeInsets.all(20), child: Text('بررسی و تأیید مدارک رانندگان', textAlign: TextAlign.center))),
  );
}
