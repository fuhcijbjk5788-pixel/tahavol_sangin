import 'package:flutter/material.dart';
class ReportsScreen extends StatelessWidget {
  const ReportsScreen({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('گزارشات')),
    body: Center(child: Padding(padding: const EdgeInsets.all(20), child: Text('گزارش‌های عملیاتی و مالی', textAlign: TextAlign.center))),
  );
}
