import 'dart:async';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AdminSplashScreen extends StatefulWidget {
  const AdminSplashScreen({super.key});
  @override State<AdminSplashScreen> createState() => _AdminSplashScreenState();
}
class _AdminSplashScreenState extends State<AdminSplashScreen> {
  @override void initState() { super.initState(); Timer(const Duration(seconds: 1), () { if (mounted) Get.offNamed('/admin_login'); }); }
  @override Widget build(BuildContext context) => const Scaffold(
    body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(Icons.admin_panel_settings, size: 90), SizedBox(height: 16),
      Text('مرکز فرماندهی', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
    ]),
  );
}
