import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/custom_textfield.dart';

class AdminLoginScreen extends StatelessWidget {
  const AdminLoginScreen({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('ورود مدیریت')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      const CustomTextField(label: 'شماره تلفن'),
      const SizedBox(height: 12), const CustomTextField(label: 'رمز عبور', obscureText: true),
      const SizedBox(height: 20), CustomButton(text: 'ورود به مرکز فرماندهی', onPressed: () => Get.offNamed('/admin_panel')),
    ]),
  );
}
