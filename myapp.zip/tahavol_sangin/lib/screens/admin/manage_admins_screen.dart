import 'package:flutter/material.dart';
class ManageAdminsScreen extends StatelessWidget {
  const ManageAdminsScreen({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('مدیریت مدیران')),
    body: Center(child: Padding(padding: const EdgeInsets.all(20), child: Text('مدیریت کاربران مدیریتی', textAlign: TextAlign.center))),
  );
}
