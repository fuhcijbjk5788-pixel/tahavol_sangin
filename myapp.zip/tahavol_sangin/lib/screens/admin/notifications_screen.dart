import 'package:flutter/material.dart';
class AdminNotificationsScreen extends StatelessWidget {
  const AdminNotificationsScreen({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('اعلان‌های مدیریت')),
    body: Center(child: Padding(padding: const EdgeInsets.all(20), child: Text('ارسال و مدیریت اعلان‌ها', textAlign: TextAlign.center))),
  );
}
