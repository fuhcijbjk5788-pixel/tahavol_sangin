import 'package:flutter/material.dart';
class TicketsScreen extends StatelessWidget {
  const TicketsScreen({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('تیکت‌های پشتیبانی')),
    body: Center(child: Padding(padding: const EdgeInsets.all(20), child: Text('رسیدگی به درخواست‌های پشتیبانی', textAlign: TextAlign.center))),
  );
}
