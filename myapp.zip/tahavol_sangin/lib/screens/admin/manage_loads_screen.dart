import 'package:flutter/material.dart';
class ManageLoadsScreen extends StatelessWidget {
  const ManageLoadsScreen({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('مدیریت بارها')),
    body: Center(child: Padding(padding: const EdgeInsets.all(20), child: Text('مدیریت بارهای ثبت‌شده', textAlign: TextAlign.center))),
  );
}
