import 'dart:async';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../config/app_config.dart';
import '../config/app_theme.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override State<SplashScreen> createState() => _SplashScreenState();
}
class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 1), () {
      if (mounted) Get.offNamed('/login');
    });
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    body: Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [AppTheme.darkGreen, AppTheme.lightGreen],
          begin: Alignment.topRight, end: Alignment.bottomLeft,
        ),
      ),
      child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: const [
        Icon(Icons.local_shipping, size: 90, color: Colors.white),
        SizedBox(height: 20),
        Text(AppConfig.appName, style: TextStyle(fontSize: 30, color: Colors.white, fontWeight: FontWeight.bold)),
        SizedBox(height: 8),
        Text(AppConfig.appNameEn, style: TextStyle(color: Colors.white70)),
      ])),
    ),
  );
}
