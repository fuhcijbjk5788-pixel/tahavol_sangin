import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ChatListScreen extends StatelessWidget {
  const ChatListScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('گفتگوها')),
    body: ListView(children: [
      ListTile(leading: const CircleAvatar(child: Icon(Icons.person)), title: const Text('گفتگو با راننده'), subtitle: const Text('پیام جدید'), onTap: () => Get.toNamed('/chat')),
    ]),
  );
}
