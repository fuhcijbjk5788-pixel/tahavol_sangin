import 'package:flutter/material.dart';

class ChatScreen extends StatelessWidget {
  const ChatScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('مکالمه')),
    body: Column(children: [
      const Expanded(child: Center(child: Text('هنوز پیامی ارسال نشده است.'))),
      Padding(padding: const EdgeInsets.all(12), child: TextField(
        decoration: InputDecoration(hintText: 'پیام خود را بنویسید...', suffixIcon: IconButton(onPressed: () {}, icon: const Icon(Icons.send))),
      )),
    ]),
  );
}
