enum LoadType { specified, instant }
enum RouteType { provincial, interProvincial }

class LoadModel {
  final String id;
  final String title;
  final String origin;
  final String destination;
  final double weight;
  final double fare;
  final LoadType type;
  final RouteType routeType;

  const LoadModel({
    required this.id,
    required this.title,
    required this.origin,
    required this.destination,
    required this.weight,
    required this.fare,
    required this.type,
    required this.routeType,
  });
}
