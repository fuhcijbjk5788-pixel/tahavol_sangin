enum UserRole { driver, owner, admin }

class UserModel {
  final String id;
  final String name;
  final String phone;
  final UserRole role;
  final String? photoUrl;

  const UserModel({
    required this.id,
    required this.name,
    required this.phone,
    required this.role,
    this.photoUrl,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
        id: '${json['id'] ?? ''}',
        name: '${json['name'] ?? ''}',
        phone: '${json['phone'] ?? ''}',
        role: UserRole.values.firstWhere(
          (e) => e.name == json['role'],
          orElse: () => UserRole.driver,
        ),
        photoUrl: json['photoUrl'] as String?,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'phone': phone,
        'role': role.name,
        'photoUrl': photoUrl,
      };
}
