import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'config/app_theme.dart';
import 'screens/auth/driver_register_screen.dart';
import 'screens/auth/login_screen.dart';
import 'screens/auth/owner_register_screen.dart';
import 'screens/chat/chat_list_screen.dart';
import 'screens/chat/chat_screen.dart';
import 'screens/common/notifications_screen.dart';
import 'screens/common/support_screen.dart';
import 'screens/common/terms_screen.dart';
import 'screens/driver/driver_home_screen.dart';
import 'screens/driver/driver_loads_screen.dart';
import 'screens/owner/owner_home_screen.dart';
import 'screens/owner/owner_loads_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/splash_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const UserApp());
}

class UserApp extends StatelessWidget {
  const UserApp({super.key});
  @override
  Widget build(BuildContext context) => GetMaterialApp(
    title: 'تحول سنگین',
    debugShowCheckedModeBanner: false,
    theme: AppTheme.lightTheme,
    darkTheme: AppTheme.darkTheme,
    themeMode: ThemeMode.system,
    locale: const Locale('fa', 'IR'),
    fallbackLocale: const Locale('fa', 'IR'),
    initialRoute: '/splash',
    getPages: [
      GetPage(name: '/splash', page: () => const SplashScreen()),
      GetPage(name: '/login', page: () => const LoginScreen()),
      GetPage(name: '/register/driver', page: () => const DriverRegisterScreen()),
      GetPage(name: '/register/owner', page: () => const OwnerRegisterScreen()),
      GetPage(name: '/driver/home', page: () => const DriverHomeScreen()),
      GetPage(name: '/owner/home', page: () => const OwnerHomeScreen()),
      GetPage(name: '/chats', page: () => const ChatListScreen()),
      GetPage(name: '/chat', page: () => const ChatScreen()),
      GetPage(name: '/driver/loads', page: () => const DriverLoadsScreen()),
      GetPage(name: '/owner/loads', page: () => const OwnerLoadsScreen()),
      GetPage(name: '/notifications', page: () => const NotificationsScreen()),
      GetPage(name: '/terms', page: () => const TermsScreen()),
      GetPage(name: '/support', page: () => const SupportScreen()),
      GetPage(name: '/profile', page: () => const ProfileScreen()),
    ],
  );
}
