import 'package:flutter_test/flutter_test.dart';
import 'package:tahavol_sangin/config/app_config.dart';

void main() {
  test('app configuration', () {
    expect(AppConfig.appName, 'تحول سنگین');
  });
}
