# تحول سنگین / مرکز فرماندهی

پروژه Flutter شامل دو ورودی:
- `lib/main_user.dart`
- `lib/main_admin.dart`

Android flavors:
- `user`
- `admin`

نمونه اجرا:
`flutter pub get`
`flutter run -t lib/main_user.dart --flavor user`
`flutter run -t lib/main_admin.dart --flavor admin`

نکته: فایل‌های واقعی فونت وزیر باید در `assets/fonts/` قرار بگیرند. تصاویر ارسال‌شده کاربر در `assets/images/` قرار داده شده‌اند.
